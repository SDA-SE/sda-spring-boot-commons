Hello,

this is some text with „UTF-8“ special characters.

Kind regards
👋
